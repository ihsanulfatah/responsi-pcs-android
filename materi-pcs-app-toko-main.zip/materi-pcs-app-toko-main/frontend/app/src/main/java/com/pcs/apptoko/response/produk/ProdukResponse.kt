package com.pcs.apptoko.response.produk

data class ProdukResponse(
    val `data`: Data,
    val message: String,
    val success: Boolean
)